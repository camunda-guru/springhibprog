package com.cts.utility;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.entities.CTSUser;
import com.cts.services.UserService;
public class ContainerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
	        ctx.scan("com.cts");//This will load the configured components UserService, UserRepository, 
	        ctx.refresh();
	        
	        System.out.println(ctx);
	        UserService userService = ctx.getBean("userService", UserService.class);
	        
	        List<CTSUser> allUser = userService.getAllUsers();
	        for (CTSUser u : allUser)
	        {
	            System.out.println(u);
	        }
	        
	        CTSUser user = new CTSUser(null, "Parameswari", "Chennai");
	        Integer id = userService.createUser(user);
	        System.out.println("Newly created User Id="+id);
	        allUser = userService.getAllUsers();
	        for (CTSUser u : allUser)
	        {
	            System.out.println(u);
	        }
	}

}
