package com.cts.repositories;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.entities.CTSUser;

@Transactional
@Repository
public class UserRepository {
	 @Autowired
	    private HibernateTemplate hibernateTemplate;
	    
	    public List<CTSUser> getAllUsers()
	    {
	        return this.hibernateTemplate.loadAll(CTSUser.class);
	    }
	    
	    public Integer createUser(CTSUser user)
	    {
	    	CTSUser mergeUser = this.hibernateTemplate.merge(user);
	        return mergeUser.getId();
	    }
}
